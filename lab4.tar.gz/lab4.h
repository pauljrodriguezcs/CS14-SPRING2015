#ifndef lab4_h
#define lab4_h

#include <iostream>
#include <list>
#include <vector>

using namespace std;

struct coord
{
    int x;
    int y;
    coord(int f, int g)
     : x(f), y(g)
    { }
};

typedef pair<int,int> Entry;
class priority_queue 
{
    public:
     vector<Entry> entries;
     Entry& front() 
     { 
         return entries.back(); 
     }

     void push(Entry e) 
     {
         entries.push_back(e);
         for (int i = entries.size()-1; i != 0; --i)
         {
             if (entries[i].first + entries[i].second < entries[i - 1].first + entries[i - 1].second) break;  // replace this comparison with code for comparing int pairs.
             swap(entries[i], entries[i-1]);
         }
     }
     
     void print()
     {
         for (int i = entries.size() - 1; i >= 0; --i)
         {
             cout << entries.at(i).first << ' ' << entries.at(i).second << endl;
         }
     }
};

void preorderhelp(int m, int n, list<coord> &l, int k)
{
    if (m + n >= k)
    {
        return;
    }
    
    coord temp(m,n);
    
    l.push_back(temp);
    
    preorderhelp((2 * m) - n, m, l, k);
    preorderhelp((2 * m) + n, m, l, k);
    preorderhelp(m + (2 * n), n, l, k);
}

void preorder(list<coord> &l, int k)
{
    preorderhelp(2, 1, l, k);
    preorderhelp(3, 1, l, k);
}

void postorderhelp(int m, int n, list<coord> &l, int k)
{
    if (m + n >= k)
    {
        return;
    }
    
    postorderhelp((2 * m) - n, m, l, k);
    postorderhelp((2 * m) + n, m, l, k);
    postorderhelp(m + (2 * n), n, l, k);
    
    coord temp(m,n);
    
    l.push_back(temp);
}

void postorder(list<coord> &l, int k)
{
    postorderhelp(2, 1, l, k);
    postorderhelp(3, 1, l, k);
}

void sorted(list<coord> &l)
{
    Entry temp;
    priority_queue pq;
    list<coord>::iterator i;
    for (i = l.begin(); i != l.end(); ++i)
    {
        temp.first = (*i).x;
        temp.second = (*i).y;
        pq.push(temp);
    }
    
    pq.print();
}

void print(list<coord> l)
{
    list<coord>::iterator i = l.begin();
    for (; i != l.end(); ++i)
    {
        cout << (*i).x << ' ' << (*i).y << endl;
    }
}

#endif