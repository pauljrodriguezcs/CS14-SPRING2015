#include <iostream>
#include <list>
#include "lab4.h"

using namespace std;

int main (int argc, char* argv[])
{
    if (argc != 2) 
    {
        cout << "not enough arguments" << endl;
        exit(-1);
    }
    
    list<coord> test1;
    
    int k = atoi(argv[1]);
    
    cout << "pre-order" << endl;
    preorder(test1, k);

    print(test1);
    
    list<coord> test2;
    
    cout << "post-order" << endl;
    postorder(test2, k);
    
    print(test2);
    
    cout << "sorted" << endl;
    
    sorted(test2);
    return 0;
}
