////////////////////
// Paul Rodriguez //
//    861152748   //
//  May 11, 2015  //
////////////////////

part a.

    My selection sort function is a stable function. This is because if there 
are two pairs of the same key type, their order are preserved according to the 
order they were in before the selection sort function was called.

part b. 

// program start

#include <iostream>
#include <algorithm>
#include <vector> 
#include <list>
#include <utility>

using namespace std;

template <typename L>
void selectionsort (L &l)
{
    if (l.size() == 0)
    {
        cout << "error: container is of size 0" << endl;
        return;
    }
    
    typename L::iterator curr = l.begin();
    typename L::iterator next;
    
    if (l.begin() == l.end()) // checks if of size one
    {
        cout << "error: container is of size 1" << endl;
        return;
    }
    
    for (; curr != l.end(); ++curr)
    {
        typename L::iterator min = curr;
        bool shouldSwap = false;
        next = curr;
        ++next;
        for (; next != l.end(); ++next) // loops to find smallest value
        {
            if (*min > *next)
            {
                min = next;
                shouldSwap = true;
            }
        }
        
        if (shouldSwap)
        {
            swap(*curr, *min);
        }
    }
}

int main()
{
    pair <int, char> p1;
    list <pair<int, char>> l2;
    
    p1 = make_pair (1,'A');
    l2.push_back(p1);
    p1 = make_pair (3,'Z');
    l2.push_back(p1);
    p1 = make_pair (-1,'Z');
    l2.push_back(p1);
    p1 = make_pair (0,'Z');
    l2.push_back(p1);
    p1 = make_pair (2,'Z'); 
    l2.push_back(p1);
    p1 = make_pair (1,'B'); 
    l2.push_back(p1);
    p1 = make_pair (1,'C');
    l2.push_back(p1);
    p1 = make_pair (8,'Z');
    l2.push_back(p1);
    
    cout << "pre: ";
    for (auto it = l2.begin(); it != l2.end(); ++it)
    {
        cout << '(' << (*it).first << ',' << (*it).second << ')' << ' ';
    }
    
    cout << endl;
    
    selectionsort(l2);
    
    cout << "post: ";
    
    for (auto it = l2.begin(); it != l2.end(); ++it)
    {
        cout << '(' << (*it).first << ',' << (*it).second << ')' << ' ';
    }
    
    cout << endl;
    
    
    return 0;
}


// program finish