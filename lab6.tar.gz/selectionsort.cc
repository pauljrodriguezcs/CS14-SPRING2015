////////////////////
// Paul Rodriguez //
//    861152748   //
//  May 11, 2015  //
////////////////////

#include <iostream>
#include <algorithm>
#include <vector> 
#include <list>
#include <utility>

using namespace std;

template <typename L>
void selectionsort (L &l)
{
    if (l.size() == 0)
    {
        cout << "error: container is of size 0" << endl;
        return;
    }
    
    typename L::iterator curr = l.begin();
    typename L::iterator next;
    
    if (l.begin() == l.end()) // checks if of size one
    {
        cout << "error: container is of size 1" << endl;
        return;
    }
    
    for (; curr != l.end(); ++curr)
    {
        typename L::iterator min = curr;
        bool shouldSwap = false;
        next = curr;
        ++next;
        for (; next != l.end(); ++next) // loops to find smallest value
        {
            if (*min > *next)
            {
                min = next;
                shouldSwap = true;
            }
        }
        
        if (shouldSwap)
        {
            swap(*curr, *min);
        }
    }
}

int main()
{
    // cout << "using vector" << endl;
    // vector <int> v;
    // v.push_back(5);
    // v.push_back(3);
    // v.push_back(4);
    // v.push_back(5);
    // v.push_back(6);
    // v.push_back(9);
    // v.push_back(3);
    // v.push_back(1);
    
    // for (unsigned int i = 0; i < v.size(); ++i)
    // {
    //     cout << v.at(i) << ' ';
    // }
    
    // cout << endl;
    
    // selectionsort(v);
    
    // for (unsigned int i = 0; i < v.size(); ++i)
    // {
    //     cout << v.at(i) << ' ';
    // }
    
    // cout << endl;
    
    // cout << "using list" << endl;
    // list <int> l;
    // selectionsort(l);
    // l.push_back(14);
    // l.push_back(13);
    // l.push_back(12);
    // l.push_back(9);
    // l.push_back(10);
    // l.push_back(16);
    // l.push_back(11);
    // l.push_back(12);
    // l.push_back(13);
    // l.push_back(14);
    // l.push_back(15);
    // l.push_back(9);
    // l.push_back(16);
    
    // for (auto it = l.begin(); it != l.end(); ++it)
    // {
    //     cout << *it << ' ';
    // }
    
    // cout << endl;
    
    // selectionsort(l);
    
    // for (auto it = l.begin(); it != l.end(); ++it)
    // {
    //     cout << *it << ' ';
    // }
    
    // cout << endl;
    
    // cout << "using pairs" << endl;
    
    // pair <int, int> p1;
    // list <pair<int, int>> l2;
    
    // p1 = make_pair (1,2);
    // l2.push_back(p1);
    // p1 = make_pair (3,-1);
    // l2.push_back(p1);
    // p1 = make_pair (-1,3);
    // l2.push_back(p1);
    // p1 = make_pair (0,0);
    // l2.push_back(p1);
    // p1 = make_pair (2,3); 
    // l2.push_back(p1);
    // p1 = make_pair (1,2); 
    // l2.push_back(p1);
    // p1 = make_pair (1,-2);
    // l2.push_back(p1);
    // p1 = make_pair (8,10);
    // l2.push_back(p1);
    
    // cout << "pre: ";
    // for (auto it = l2.begin(); it != l2.end(); ++it)
    // {
    //     cout << '(' << (*it).first << ',' << (*it).second << ')' << ' ';
    // }
    
    // cout << endl;
    
    // selectionsort(l2);
    
    // cout << "post: ";
    
    // for (auto it = l2.begin(); it != l2.end(); ++it)
    // {
    //     cout << '(' << (*it).first << ',' << (*it).second << ')' << ' ';
    // }
    
    // cout << endl;
    
    // cout << "using sorted pairs" << endl;
    
    // pair <int, int> p1;
    // list <pair<int, int>> l2;
    
    // p1 = make_pair (-1,3);
    // l2.push_back(p1);
    // p1 = make_pair (0,0);
    // l2.push_back(p1);
    // p1 = make_pair (1,-2);
    // l2.push_back(p1);
    // p1 = make_pair (1,2);
    // l2.push_back(p1);
    // p1 = make_pair (1,2); 
    // l2.push_back(p1);
    // p1 = make_pair (2,3); 
    // l2.push_back(p1);
    // p1 = make_pair (3,-1);
    // l2.push_back(p1);
    // p1 = make_pair (8,10);
    // l2.push_back(p1);
    
    // cout << "pre: ";
    // for (auto it = l2.begin(); it != l2.end(); ++it)
    // {
    //     cout << '(' << (*it).first << ',' << (*it).second << ')' << ' ';
    // }
    
    // cout << endl;
    
    // selectionsort(l2);
    
    // cout << "post: ";
    
    // for (auto it = l2.begin(); it != l2.end(); ++it)
    // {
    //     cout << '(' << (*it).first << ',' << (*it).second << ')' << ' ';
    // }
    
    // cout << endl;
    
    
    pair <int, char> p1;
    list <pair<int, char>> l2;
    
    p1 = make_pair (1,'A');
    l2.push_back(p1);
    p1 = make_pair (3,'Z');
    l2.push_back(p1);
    p1 = make_pair (-1,'Z');
    l2.push_back(p1);
    p1 = make_pair (0,'Z');
    l2.push_back(p1);
    p1 = make_pair (2,'Z'); 
    l2.push_back(p1);
    p1 = make_pair (1,'B'); 
    l2.push_back(p1);
    p1 = make_pair (1,'C');
    l2.push_back(p1);
    p1 = make_pair (8,'Z');
    l2.push_back(p1);
    
    cout << "pre: ";
    for (auto it = l2.begin(); it != l2.end(); ++it)
    {
        cout << '(' << (*it).first << ',' << (*it).second << ')' << ' ';
    }
    
    cout << endl;
    
    selectionsort(l2);
    
    cout << "post: ";
    
    for (auto it = l2.begin(); it != l2.end(); ++it)
    {
        cout << '(' << (*it).first << ',' << (*it).second << ')' << ' ';
    }
    
    cout << endl;
    
    
    return 0;
}