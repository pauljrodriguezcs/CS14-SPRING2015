////////////////////
// Paul Rodriguez //
//    861152748   //
//  May 11, 2015  //
////////////////////
#ifndef selectionsort_h
#define selectionsort_h

#include <iostream>
#include <algorithm>
#include <vector> 
#include <list>
#include <utility>

using namespace std;

template <typename L>
void selectionsort (L &l)
{
    if (l.size() == 0)
    {
        cout << "error: container is of size 0" << endl;
        return;
    }
    
    typename L::iterator curr = l.begin();
    typename L::iterator next;
    
    if (l.begin() == l.end()) // checks if of size one
    {
        cout << "error: container is of size 1" << endl;
        return;
    }
    
    for (; curr != l.end(); ++curr)
    {
        typename L::iterator min = curr;
        bool shouldSwap = false;
        next = curr;
        ++next;
        for (; next != l.end(); ++next) // loops to find smallest value
        {
            if (*min > *next)
            {
                min = next;
                shouldSwap = true;
            }
        }
        
        if (shouldSwap)
        {
            swap(*curr, *min);
        }
    }
}

#endif