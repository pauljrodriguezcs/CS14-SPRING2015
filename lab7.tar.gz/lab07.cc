////////////////////
// Paul Rodriguez //
//    861152748   //
//  May 24, 2015  //
////////////////////
#include <iostream>
#include <fstream>
#include <vector>
#include <set>
#include <unordered_set>
#include <algorithm>
#include <ctime>

using namespace std;

int main (int argc, char* argv[])
{
    vector <string> v; // vector to hold words from file
    
    if (argc != 3) 
    {
        cout << "not enough arguments" << endl;
        exit(-1);
    }
    
    ifstream fin;
    
    fin.open(argv[1]);
    
    if (!fin.is_open())
    {
        cout << "Error opening words.txt" << endl;
        exit(0);
    }
    
    ofstream fout;
    
    fout.open(argv[2]);
    
    if (!fout.is_open())
    {
        cout << "Error opening data.txt" << endl;
        exit(0);
    }
    
    // fout << "<n> <tree-insert-time> <hash-insert-time> ";
    // fout << "<tree-query-time> <hash-query-time>" << endl;
    
    string word;
    
    while (fin >> word) // will fill vector until no more reading in
    {
        v.push_back(word);
    }
    
    set<string> s; // creates self-balancing tree (set)
    set<string>::iterator s_it = s.begin();
    
    unordered_set <string> us; // creates hash table (unordered_set)
    
    vector<vector<double>> tree_insert_time(10, vector<double> (10));
    vector<vector<double>> hash_insert_time(10, vector<double> (10));
    vector<vector<double>> tree_query_time(10, vector<double> (10));
    vector<vector<double>> hash_query_time(10, vector<double> (10));
    
    double s_insert_time = 0.0;
    double us_insert_time = 0.0;
    
    double s_query_time = 0.0;
    double us_query_time = 0.0;
    
    int insert_start = 0;
    int insert_end = 0;
    
    int query_start = 0;
    int query_end = 0;
    
    for (unsigned t = 0; t < 10; ++t) // number of runs
    {
        for (unsigned n = 5000; n <= 50000; n = n + 5000)
        {
            insert_start = clock(); // starts timer for set
            
            for (unsigned j = n - 5000; j < n; ++j) // inserts into set s
            {
                s.insert(s_it, v.at(j));
            }
            
            insert_end = clock(); // ends timer for set
            
            s_insert_time = (((float)insert_end - insert_start)/CLOCKS_PER_SEC)/n;
            
            insert_start = clock(); // starts timer for unsorted_set
            
            for (unsigned j = n - 5000; j < n; ++j)
            {
                us.insert(v.at(j));
            }
            
            insert_end = clock(); // ends timer for unsorted_set
            
            us_insert_time = (((float)insert_end - insert_start) / CLOCKS_PER_SEC)/n;
            
            query_start = clock(); // starts time for set
    
            for (unsigned j = n - 5000; j < n; ++j) // looks up the word
            {
                s.find(v.at(j));
            }
    
            query_end = clock(); // ends timer for set
            
            s_query_time = (((float)query_end - query_start) / CLOCKS_PER_SEC)/n; 
            
            query_start = clock(); // starts timer for unsorted_set
    
            for (unsigned j = n - 5000; j < n; ++j)
            {
                us.find(v.at(j));
            }
    
            query_end = clock(); // ends timer for unsorted_set
    
            us_query_time = (((float)query_end - query_start) / CLOCKS_PER_SEC)/n;
            
            unsigned pos = (n/5000) - 1; // position in second vector
            
            // inserts times into corresponding vector
            tree_insert_time.at(t).at(pos) = s_insert_time;
            hash_insert_time.at(t).at(pos) = us_insert_time;
            tree_query_time.at(t).at(pos) = s_query_time;
            hash_query_time.at(t).at(pos) = us_query_time;
        }
        
        random_shuffle(v.begin(), v.end());
    }
    
    vector<double> avg_results_tree_insert(10);
    vector<double> avg_results_hash_insert(10);
    vector<double> avg_results_tree_query(10);
    vector<double> avg_results_hash_query(10);
    
    for (unsigned i = 0; i < 10; ++i) // will fill the avg vectors
    {
        double ti = 0.0;
        double hi = 0.0;
        double tq = 0.0;
        double hq = 0.0;
        
        // goes through the vector that keeps track of the times and adds to 
        // temp variables (ti, hi, etc.)
        for (unsigned j = 0; j < 10; ++j)
        {
            ti = ti + tree_insert_time.at(j).at(i);
            hi = hi + hash_insert_time.at(j).at(i);
            tq = tq + tree_query_time.at(j).at(i);
            hq = hq + hash_query_time.at(j).at(i);
        }
        
        avg_results_tree_insert.at(i) = ti / 10;
        avg_results_hash_insert.at(i) = hi / 10;
        avg_results_tree_query.at(i) = tq / 10;
        avg_results_hash_query.at(i) = hq / 10;
    }
    
    // dumps results into file
    for (unsigned i = 0, z = 5000; i < 10; ++i, z = z + 5000)
    {
        fout << z << ' ' << avg_results_tree_insert.at(i) << ' '
            << avg_results_hash_insert.at(i) << ' ' 
            << avg_results_tree_query.at(i) << ' ' 
            << avg_results_hash_query.at(i) << endl;
    }
    
    fin.close();
    fout.close();
    
    return 0;
}