////////////////////
// Paul Rodriguez //
//    861152748   //
//  May 24, 2015  //
////////////////////

hashtables

    pros:
    - when evenly dispersed, insertion, lookup, and deletion take O(1)
    - they work a lot better when only using it with small amounts of data
    
    cons:
    - when using large amounts of data, insertion, lookup, and deletion take O(n)
    - using large amounts of data can cause collision between data
    - approximate size of hashtable has to be known before hand or resizing will occur
    
bst

    pros:
    - order of data is maintained
    - in order traversal of tree is O(n)
    - insertion, deletion of elements is O(n log n)
    
    cons:
    - regardless of size, insertion and deletion take O(n log n)
    
    
Another way of testing for times, will be deletion of items in order, and then 
in random order. Using a really small amount of data should be used to compare
both algorithms in insertion, lookup and deletion times. 