
#include <iostream>
#include "lab5.h"

int main()
{
    // Test Case 1
        // Part 1
    BST <int>test1;
    
    cout << "testcase: 1" << endl;
    test1.insert(50);
    test1.insert(20);
    test1.insert(10);
    test1.insert(40);
    test1.insert(35);
    test1.insert(45);
    test1.insert(60);
    test1.insert(70);
    
    cout << "Part 1" << endl;
    test1.minCover();
    test1.displayMinCover();
    
    cout << "Part 2" << endl;
    test1.findSumPath(80);
    test1.findSumPath(180);
    test1.findSumPath(190);
    test1.findSumPath(145);
    test1.findSumPath(155);
    cout << "Part 3" << endl;
    test1.vertSum();
    cout << endl;
    
    
    cout << endl;
    
    // // Testcase 2
    //     // part 1
    // BST <int>test2;
    
    
    // cout << "testcase: 2" << endl;
    // test2.insert(50);
    // test2.insert(20);
    // test2.insert(10);
    // test2.insert(40);
    // test2.insert(35);
    // test2.insert(45);
    // test2.insert(60);
    // test2.insert(70);
    // test2.insert(38);
    // test2.insert(55);
    // test2.insert(65);
    // test2.insert(47);
    
    // cout << "Part 1" << endl;
    // test2.minCover();
    // test2.displayMinCover();
    
    // cout << "Part 3" << endl;
    // test2.vertSum();
    // cout << endl;
    return 0;
}