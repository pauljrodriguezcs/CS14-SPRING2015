////////////////////
// Paul Rodriguez //
//    861152748   //
//  May 4, 2015   //
////////////////////

#ifndef lab5_h
#define lab5_h
#include <cassert>
#include <iostream>
#include <fstream>
#include <cstdlib>
#include <string>
#include <sstream>
#include <map>
#include <list>
#include <vector>
#include <math.h>
using namespace std;
#define nil 0

// #define Value int // restore for testing.
template < typename Value >
class BST {
    class Node { // binary tree node
     public:
      Node* left;
      Node* right;
      Value value;
      bool isSelect;
      Node( const Value v = Value() )
       : left(nil), right(nil), value(v), isSelect(false)
      { }
      Value& content() { return value; }
      bool isInternal() { return left != nil && right != nil; }
      bool isExternal() { return left != nil || right != nil; }
      bool isLeaf() { return left == nil && right == nil; }
      int height() { // done
          // returns the height of the subtree rooted at this node
          // FILL IN
          if (isLeaf())
             {
                 return 0;
             }
            
             return 1;
          }
          
      int size() { // done
          // returns the size of the subtree rooted at this node,
          // FILL IN
          if (isLeaf())
             {
                 return 1;
             }
            
             else if (isExternal())
             {
                 return 2;
             }
            return 3;
          }
    }; // Node

    // const Node* nil; // later nil will point to a sentinel node.
    Node* root;
    int count;
    vector<Node*> v;
    
    public:
     int size() { // done
         // size of the overall tree.
         // FILL IN
         if (root == nil) // base case
         {
             cout << "nothing in tree...";
             return 0;
         }
         
         return size(root);
     }
     
     int size(Node *n) // done
     {
         int sz = 0;
         
         if (n == nil) // base case
         {
             return 0;
         }
         
         if (n->isLeaf()) // if leaf node
         {
             sz = 1;
             return sz; 
         }
         
         sz = sz + size(n->right);
         sz = sz + size(n->left);
         
         return sz + 1; // adds one to the for the current node
     }
     
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//////////////////            LAB 5 FUNCTIONS            ///////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////

     void minCover() // implement
     {
         minCover(root->left); // calls on left of root
         minCover(root->right); // calls on right of root
     }
     
     void minCover(Node *n)
     {
         if (n == nil) // if node is empty
         {
             return;
         }
         
         minCover(n->left); // go to left of node
         
         if (n->size() > 1) // if node is more than one
         {
             v.push_back(n);
             n->isSelect = true;
         }
         
         minCover(n->right);
     }
     
     void displayMinCover()
     {
         int i = 0;
         for (; i < v.size(); ++i)
         {
             cout << v.at(i)->value << ' ';
         }
         
         cout << endl;
         cout << i << endl;
     }
     
     void printSum(int buffer[], int size)
     {
         int temp;

         for(int i = 1; i <= size; i++) // sorts array int ascending order
         {
              for(int j = i + 1; j <= size; j++)
              {
                   if (buffer[j] > buffer[i])
                   {
                       //swap them
                      temp = buffer[i];
                      buffer[i] = buffer[j];
                      buffer[j] = temp;
                   }
              }
         }

         for (int i = size; i > 0; --i)
         {
             cout << buffer[i] << ' ';
         }
         
         cout << endl;
     }
     
     void findSumPath(Node* n, int sum, int buffer[], int loc, bool &isFound)
     {
         if (n == nil) // if node is empty
         {
             return;
         }
   
         buffer[++loc] = n->value; // add value of node to buffer
         // cout << "loc: " << loc << endl;
         // cout << "n->value: " << n->value << endl;

         if (n->isLeaf())
         {
             // cout << "inside isleaf" << endl;
             int temp = 0; // keep sum of buffer
             
             for (int i = 1; i <= loc; ++i)
             {
                 temp = temp + buffer[i];
             }
             
             if (temp == sum)
             {
                 isFound = true; // path is found
                 printSum(buffer, loc); // calls print funcion
             }
             
             loc = 1; // reset array location back to 1
         }
         
         if (!isFound) // if path has not been found try both subtrees
         {
             findSumPath(n->left, sum, buffer, loc, isFound);
             
             if (!isFound) // if path has not been found on left, try right
             {
                findSumPath(n->right, sum, buffer, loc, isFound);
             }
         }
      }
     
     void findSumPath(int sum)
     {
         if (root == nil)
         {
             cout << '0';
             return;
         }
         
         if (root->value == sum)
         {
             cout << root->value;
             return;
         }
         
         int buff[1000]; // array for storing values
         int location = 0; // keeps track of items in array
         bool isFound = false; // keeps track if path is found
         findSumPath(root, sum, buff, location, isFound);
         
         if (!isFound) // if path was not found
         {
             cout << "0" << endl;
         }
     }
     
     void vertSum(Node* node, int hd, std::map<int, int>& m)
     {
        //  cout << "hd value: " <<  hd;
        //  cout << " node value:" << node->value << endl;
         m[hd] = m[hd] + node->value;
         
         if (node->left != nil)
         {
             --hd;
             vertSum(node->left, hd, m);
             ++hd;
         }
         
         if (node->right != nil)
         {
             ++hd;
             vertSum(node->right, hd, m);
             --hd;
         }
         
         return;
     }
     
     void displayVertSum(map<int, int> m)
     {
         map<int,int>::iterator mp = m.begin();
         for (; mp != m.end(); ++mp)
         {
             cout << m[mp->first] << ' ';
         }
     }
     
     void vertSum()
     {
         if (root == nil)
         {
             cout << '0';
             return;
         }
         map<int, int> m;
         vertSum(root, 0, m);
         displayVertSum(m);
     }
     
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//////////////////              End of LAB 5             ///////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
     
     bool empty() { return size() == 0; }
     
     void print_node( const Node* n ) { // done
         // Print the node’s value.
         // FILL IN
         cout << n->value;
     }
    
     bool searchTree(Node *n, Value x) const // done
     {
         bool response = false;
         if (n == nil) // basecase
         {
             return false;
         }
         
         if (n->content() == x)
         {
             return true;
         }

         response = searchTree(n->left, x);
         if (!response)
         {
             response = searchTree(n->right, x);
         }
         return response;
     }
         
     bool search ( Value x ) { // done
         // search for a Value in the BST and return true iff it was found.
         // FILL IN
         if (empty())
         {
            cout << "nothing in tree...";
            return false;
         }
         
         return searchTree(root, x);
         }
     
     void preorderHelp(Node* n) const // done
     {
         if (n == nil) // basecase
         {
             return;
         }
         
         cout << n->content() << ' ';
         preorderHelp(n->left);
         preorderHelp(n->right);
         return;
     }
     
     void preorder()const { // done
         // Traverse and print the tree one Value per line in preorder.
         // FILL IN
         if (root == nil) // base case
         {
             cout << "nothing in tree...";
             return;
         }
         
         preorderHelp(root); // call helper function
         }
         
     void postorderHelp(Node *n) const // done
     {
         if (n == nil) // base case
         {
             return;
         }
         
         postorderHelp(n->left);
         postorderHelp(n->right);
         cout << n->content() << ' ';
     }
     
     void postorder()const { // done
         // Traverse and print the tree one Value per line in postorder.
         // FILL IN
         if (root == nil) // base case
         {
            cout << "nothing in tree...";
            return;
         }  
         
         postorderHelp(root);
         
         }
         
     void inorderHelp(Node *n) const // done
     {
         if (n == nil) // base case
         {
             return;
         }
         
         inorderHelp(n->left);
         cout << n->content() << ' ';
         inorderHelp(n->right);
     }
     void inorder()const { // done
         // Traverse and print the tree one Value per line in inorder.
         // FILL IN
         if (root == nil)
         {
             cout << "nothing in tree...";
             return;
         }
         
         inorderHelp(root);
         
         }
         
     void operatorHelp(Node *x, vector <Node*> &v) const
     {
         if (x == nil) // base case
         {
             return;
         }
         
         operatorHelp(x->left, v);
         v.push_back(x);
         operatorHelp(x->right,v);
     }
         
     Value& operator[] (int n) {
         // returns reference to the value field of the n-th Node.
         // FILL IN
         if (n >= size())
         {
             cout << n << " is out of bounds" << endl;
             exit(-1);
         }
         
         if (root == nil)
         {
             cout << "empty list" << endl;
             exit(-1);
         }
         
         vector <Node*> v;
         
         operatorHelp(root, v);
         
         return v.at(n)->value;
         }
         
     BST() :root(nil), count(0), v() {}
     
     
     void insert( Value X ) { root = insert( X, root ); }
     Node* insert( Value X, Node* T ) {
         // The normal binary-tree insertion procedure ...
         if ( T == nil ) {
             T = new Node( X ); // the only place that T gets updated.
         } else if ( X < T->value ) {
             T->left = insert( X, T->left );
                 
         } else if ( X > T->value ) {
             T->right = insert( X, T->right );
                 
         } else {
             T->value = X;
                 
         }
         // later, rebalancing code will be installed here
         return T;
     }
     
     void remove( Value X ) { root = remove( X, root ); }
     Node* remove( Value X, Node*& T ) {
         // The normal binary-tree removal procedure ...
         // Weiss’s code is faster but way more intricate.
         if ( T != nil ) {
             if ( X > T->value ) {
                 T->right = remove( X, T->right );
             } else if ( X < T->value ) {
                 T->left = remove( X, T->left );
                 
             } else { // X == T->value
             if ( T->right != nil ) {
                 Node* x = T->right;
                 while ( x->left != nil ) x = x->left;
                 T->value = x->value; // successor’s value
                 T->right = remove( T->value, T->right );
             } else if ( T->left != nil ) {
                 Node* x = T->left;
                 while ( x->right != nil ) x = x->right;
                 T->value = x->value; // predecessor’s value
                 T->left = remove( T->value, T->left );
             } else { // *T is external
             delete T;
             T = nil; // the only updating of T
             }
             }
         }  
     // later, rebalancing code will be installed here
     return T;
     }
     
     void okay( ) { okay( root ); }
     void okay( Node* T ) {
     // diagnostic code can be installed here
     return;
     }
}; // BST
#endif