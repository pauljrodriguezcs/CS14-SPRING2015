// Paul Rodriguez
// 861152748
// April 18, 2015

#ifndef lab2_h
#define lab2_h

#include <forward_list>
#include <vector>
#include <iostream>

using namespace std;

///////////////////////////////////////////////////////////////////////////// 1)
bool isPrime(int i)
{
    if (i == 1)
    {
        return false;
    }
    
    for (int j = 2; j < i; ++j) // dividend will increment until less than int i
    {
        if (i % j == 0) // if i % j then that means number is not prime
        {
            return false;
        }
    }
    
    // i has no other divident but 1 and itself
    return true;
}

int primeCount(forward_list<int> lst)
{
    if (lst.empty()) // checks an emtpy list
    {
        return 0;
    }
    
    int cnt = 0; // will keep track number of traverses
    
    forward_list<int>::iterator i;
    i = lst.begin();

    if (isPrime(*i)) // calls helper function
    {
        ++cnt; // increment by one 
    }
    
    lst.pop_front(); // deletes first node
    
    
    return cnt + primeCount(lst); // returns sum of cnts
}

///////////////////////////////////////////////////////////////////////////// 2)
template <typename Type>
struct Node
{
    Type value;
    Node *next;
    Node(Type value) 
     : value(value), next(0)
    { }
};

template <class Type>
class List
{
    private:
     Node <Type> *head;
     Node <Type> *tail;
     int size;
    public:
     List();
     List(const List& lst);
     ~List();
     int length();
     void display();
     void push_front(Type value);
     void push_back(Type value);
     void pop_front();
     void pop_back();
     void elementSwap(int pos);
     List<Type>& operator=(const List<Type>& lst);
};

template <class Type>
List<Type>::List()
 : head(0), tail(0), size(0)
{ }

template <class Type>
List<Type>::List(const List& lst)
 : head(0), tail(0), size(0)
{
    Node <Type> *curr = lst.head;
    
    if (curr == 0) // empty list
    {
        return;
    }
    
    do{ // fill up list
        push_back(curr->value);
        curr = curr->next;
    } while (curr != 0);
}

template <class Type>
List<Type>::~List()
{
    if (head == 0)
    {
        return;
    }
    
    do {
        pop_back();
    } while (head != 0);
}
template <class Type>
int List<Type>::length()
{
    return size; // returns size
}

template <class Type>
void List<Type>::display()
{
    if (head == 0) // empty list
    {
        cout << "Nothing to display";
        return;
    }
    
    Node <Type> *curr = head; // node that will traverse list
    
    cout << curr->value; // updates
    curr = curr->next;
    
    while (curr != 0) // traverse until end of list
    {
        cout << ' ' << curr->value;
        curr = curr->next;
    }
}

template <class Type>
void List<Type>::push_front(Type value)
{
    Node <Type> *temp = new Node<Type>(value);
    temp->next = head;
    head = temp;
    
    if (tail == 0)
    {
        tail = head;
    }
    
    ++size; // increment size by one
}

template <class Type>
void List<Type>::push_back(Type value)
{
    Node <Type> *temp = new Node<Type>(value);
    
    if (tail == 0)
    {
        head = temp;
        tail = temp;
    }
    
    tail->next = temp;
    tail = temp;
    
    ++size; // increment size by one
}

template <class Type>
void List<Type>::pop_front()
{
    if (head == 0) // empty list
    {
        cout << "error: no nodes in list" << endl;
        return;
    }
    
    Node <Type> *temp = head->next;
    delete head;
    head = temp;
    
    if (head == 0) // if only one list was in the node before delete
    {
        tail = 0;
    }
    
    --size; // decrease size
}

template <class Type>
void List<Type>::pop_back()
{
    if (head == 0) // empty list
    {
        cout << "error: no nodes in list" << endl;
        return;
    }
    
    if (head == tail) // list of one
    {
        delete head;
        head = 0;
        tail = 0;
        --size;
        return;
    }
    
    Node <Type> *curr = head; // starts at head
    int cnt = 1; // position of curr is at one
    
    
    while (cnt < size - 1) // incurement curr until it is one node behind tail
    {
        curr = curr->next;
        ++cnt;
    }
    
    delete tail;
    curr->next = 0;
    tail = curr;
    
    --size; // decrease size
}

template <class Type>
void List<Type>::elementSwap(int pos)
{
    
    if (size == pos) // if pos is the size, error at pos + 1
    {
        cout << "error no element in spot " << pos + 1 << endl;
        return;
    }
    
    if (pos <= 0 || pos > size) // if pos is less than 1 or greater than size
    {
        cout << "error no element in spot " << pos << endl;
        return;
    }
    
    Node <Type> *curr = head; // will traverse list
    int cnt = 1; // position of head
    
    while (cnt < pos) // traverse until pos is reached
    {
        curr = curr->next;
        ++cnt;
    }
    
    Node <Type> *after = curr->next; // node after curr
    
    if (pos == 1) // if first node is to be swapped
    {
        curr->next = after->next;
        after->next = curr;
        head = after;
        if (curr->next == 0)
        {
            tail = curr;
        }
        return;
    }
    
    Node <Type> *pred = head; // node to be before curr
    cnt = 1; // posiiton of pred
    
    while (cnt < pos - 1) // will traverse until one less than curr
    {
        pred = pred->next;
        ++cnt;
    }
    
    curr->next = after->next;
    after->next = curr;
    pred->next = after;
    
    if (curr->next == 0) // if curr is last element in the list
    {
        tail = curr;
    }
    
    return;
}

template <class Type>
List<Type>& List<Type>::operator=(const List<Type>& lst)
{
    if (this != &lst && lst.head != 0) // checks if not self assign 
    {                                  // and if lst is not empty
        Node <Type> *curr = lst.head;
        
        if (head == 0) // if this is empty just pushback the values
        {
            do{
                push_back(curr->value);
                curr = curr->next;
            } while (curr != 0);
            
            return *this;
        }
        
        while (head != 0) // first delete everything and then pushback values
        {
            pop_back();
        }
        
        do{
            push_back(curr->value);
            curr = curr->next;
        } while (curr != 0);
        
        return *this;
    }
    
    while (head != 0) // if the second lst is empty just delete everything here
    {
        pop_back();
    }
    
    return *this;
}

///////////////////////////////////////////////////////////////////////////// 3)
template <typename Type>
void listCopy(forward_list <Type> L, forward_list <Type> &P)
{
    vector <Type> temp; // vector to hold values from L
    typename forward_list<Type>::iterator i = L.begin();

    while (i != L.end()) // push values from list to vector 
    {
        temp.push_back(*i);
        ++i;
    }
    
    i = P.begin();
    
    unsigned j = 0;
    
    while (j != temp.size()) // now push values from vector to list P
    {
        P.push_front(temp.at(j));
        ++j;
    }
}

///////////////////////////////////////////////////////////////////////////// 4)
template <typename Type>
void printLots (forward_list <Type> L, forward_list <int> P)
{
    forward_list <int>::iterator i; // will traverse P
    typename forward_list <Type>::iterator s; // will traverse L
    int size = 0;
    
    while (s != L.end()) // iterator that traverses the list L to get the size
    {
        ++size; 
        ++s;
    }
    
    for (i = P.begin(); i != P.end(); ++i)
    {
        if (*i > size || *i == 0) // checks to see if any out of bounds
        {
            cout << "error: element " << *i << " is out of bounds" << endl;
            return;
        }
    }
    
    for (i = P.begin(); i != P.end(); ++i)
    {
        typename forward_list <Type>::iterator l = L.begin(); // traverses l
        int count = 1; // position one
        while (count < *i) // updates count and l until *i is reached
        {
            ++l;
            ++count;
        }
        cout << *l << endl; // outputes *l
    }
}

#endif