// Paul Rodriguez
// 861152748
// April 18, 2015

#include <forward_list>
#include <iostream>
#include "lab2.h"

using namespace std;

int main()
{
    // forward_list <int> fl = {1,2,3,4,5,6,7,8,9,10};
    
    // cout << "prime count: " << primeCount(fl) << endl;
    
    // forward_list <char> L = {'a','b','c','d','e','f','g','h','i'};
    // forward_list <int> P = {9, 8 ,5, 3, 1};
    
    
    // forward_list <char>::iterator l = L.begin();
    // forward_list <int>::iterator p = P.begin();
    
    // cout << *l;
    // ++l;
    // cout << "before: " << endl;
    // for (; l != L.end(); ++l)
    // {
    //     cout << ' ' << *l;
    // }
    // cout << endl;
    
    // listCopy(L, P);
    
    // cout << "after: " << endl;
    // cout << *p;
    // ++p;
    // for (; p != P.end(); ++p)
    // {
    //     cout << ' ' << *p;
    // }
    // cout << endl;
    
    // printLots(L, P);
    
    List <int> l1;
    l1.push_front(9);
    l1.push_front(8);
    l1.push_front(7);
    l1.push_front(6);
    l1.push_front(5);
    l1.push_front(4);
    l1.push_front(3);
    l1.push_front(2);
    l1.push_front(1);

    cout << l1.length() << endl;

    l1.display();
    cout << endl;
    
    l1.push_back(10);
    l1.push_back(11);
    l1.push_back(12);
    l1.push_back(13);
    l1.push_back(14);
    l1.push_back(15);
    l1.push_back(16);
    
    
    cout << l1.length() << endl;
    l1.display();
    cout << endl;
    
    // List <int> l2(l1);
    // cout << l2.length() << endl;
    // l1.display();
    // cout << endl;
    
    // List <int> l3;
    // l3 = l2;
    // l3.display();
    // cout << endl;

    // l1.display();
    // cout << endl;
    
    l1.elementSwap(1);
    
    l1.display();
    cout << endl;
    
    l1.elementSwap(2);
    
    l1.display();
    cout << endl;
    
    l1.elementSwap(3);
    
    l1.display();
    cout << endl;
    
    l1.elementSwap(4);
    
    l1.display();
    cout << endl;
    
    l1.elementSwap(15);
    
    l1.display();
    cout << endl;
    
    l1.elementSwap(0);
    
    l1.display();
    cout << endl;
    
    l1.elementSwap(16);
    
    l1.display();
    cout << endl;
    
    l1.elementSwap(17);
    
    l1.display();
    cout << endl;
    
    // l1.pop_front();
    // l1.pop_back();
    
    // l1.pop_front();
    // l1.pop_back();
    
    // l1.pop_front();
    // l1.pop_back();
    
    // l1.pop_front();
    // l1.pop_back();
    
    // cout << l1.length() << endl;

    // l1.display();
    // cout << endl;
    
    // l1.pop_front();
    // l1.pop_back();
    
    // l1.pop_front();
    // l1.pop_back();
    
    // l1.pop_front();
    // l1.pop_back();
    
    // cout << l1.length() << endl;

    // l1.display();
    // cout << endl;
    
    // l1.pop_front();
    // l1.pop_back();
    
    // cout << l1.length() << endl;

    // l1.display();
    // cout << endl;
    
    // l1.pop_front();
    // l1.pop_back();
    
    // cout << l1.length() << endl;

    // l1.display();
    // cout << endl;
    
    return 0;
}