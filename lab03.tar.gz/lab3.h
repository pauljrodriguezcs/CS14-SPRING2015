////////////////////
// Paul Rodriguez //
//    861152748   //
// April 20, 2015 //
////////////////////
#ifndef lab3_h
#define lab3_h

#include <iostream>
#include <stack>

using namespace std;

// Part 1 //////////////////////////////////////////////////////////////////////
template <class T>
class TwoStackFixed
{
    private: 
     int sizeArr;
     int stack1;
     int inStack1;
     int stack2;
     int inStack2;
     int max;
     T *arr;
    public:
     TwoStackFixed(int size, int maxtop);
     void pushStack1(T value);
     void pushStack2(T value);
     T popStack1();
     T popStack2();
    private:
     bool isFullStack1();
     bool isFullStack2();
     bool isEmptyStack1();
     bool isEmptyStack2();
};

template <class T>
TwoStackFixed<T>::TwoStackFixed(int size, int maxtop)
 : sizeArr(size), stack1(0), inStack1(0), stack2(0), inStack2(0), 
   max(maxtop - 1), arr(0)
{  
    if (maxtop > size)
    {
        cout << "error: maxtop is bigger than size" << endl;
        exit(1);
    }
    stack1 = maxtop;
    stack2 = sizeArr - maxtop;
    arr = new T[sizeArr];
}

template <class T>
void TwoStackFixed<T>::pushStack1(T value)
{
    if (isFullStack1())
    {
        cout << "error: stack1 is full" << endl;
        return;
    }
    
    arr[inStack1] = value;
    ++inStack1;
}

template <class T>
void TwoStackFixed<T>::pushStack2(T value)
{
    if (isFullStack2())
    {
        cout << "error: stack1 is full" << endl;
        return;
    }
    
    arr[sizeArr - 1 - inStack2] = value;
    ++inStack2;
}

template <class T>
T TwoStackFixed<T>::popStack1()
{
    if (isEmptyStack1())
    {
        cout << "error";
        exit(1);
    }
    
    T temp = arr[inStack1 - 1];
    arr[inStack1 - 1] = ' ';
    --inStack1;
    return temp;
}

template <class T>
T TwoStackFixed<T>::popStack2()
{
    if (isEmptyStack2())
    {
        cout << "error" << endl;
        exit(1);
    }
    
    T temp = arr[sizeArr - inStack2];
    arr[sizeArr - inStack2] = ' ';
    --inStack2;
    return temp;
}

template <class T>
bool TwoStackFixed<T>::isFullStack1()
{
    if (inStack1 >= stack1)
    {
        return true;
    }
    
    return false;
}

template <class T>
bool TwoStackFixed<T>::isFullStack2()
{
    if (inStack2 >= stack2)
    {
        return true;
    }
    
    return false;
}

template <class T>
bool TwoStackFixed<T>::isEmptyStack1()
{
    if (inStack1 == 0)
    {
        return true;
    }
    
    return false;
}

template <class T>
bool TwoStackFixed<T>::isEmptyStack2()
{
    if (inStack2 == 0)
    {
        return true;
    }
    
    return false;
}

// Part 2 //////////////////////////////////////////////////////////////////////

template <class T>
class TwoStackOptimal
{
    private: 
     int sizeArr;
     int stack1;
     int stack2;
     int inStack1;
     int inStack2;
     T *arr;
    public:
     TwoStackOptimal(int size);
     void pushFlexStack1(T value);
     void pushFlexStack2(T value);
     T popFlexStack1();
     T popFlexStack2();
    private:
     bool isFullStack1();
     bool isFullStack2();
     bool isEmptyStack1();
     bool isEmptyStack2();
};

template <class T>
TwoStackOptimal<T>::TwoStackOptimal(int size)
 : sizeArr(size), stack1(0), stack2(0), inStack1(0), inStack2(0), arr(0)
{
    arr = new T[sizeArr];
}

template <class T>
void TwoStackOptimal<T>::pushFlexStack1(T value)
{
    if (isFullStack1())
    {
        cout << "error: stack1 is full" << endl;
        return;
    }
    
    arr[inStack1] = value;
    ++inStack1;
}

template <class T>
void TwoStackOptimal<T>::pushFlexStack2(T value)
{
    if (isFullStack2())
    {
        cout << "error: stack2 is full" << endl;
        return;
    }
    
    arr[(sizeArr - 1) - inStack2] = value;
    ++inStack2;
}

template <class T>
T TwoStackOptimal<T>::popFlexStack1()
{
    if (isEmptyStack1())
    {
        cout << "error" << endl;
        exit(1);
    }
    
    T temp = arr[inStack1 - 1];
    arr[inStack1 - 1] = ' ';
    --inStack1;
    return temp;
}

template <class T>
T TwoStackOptimal<T>::popFlexStack2()
{
    if (isEmptyStack2())
    {
        cout << "error" << endl;
        exit(1);
    }
    
    T temp = arr[sizeArr - inStack2];
    arr[sizeArr - inStack2] = ' ';
    --inStack2;
    return temp;
}

template <class T>
bool TwoStackOptimal<T>::isFullStack1()
{
    if (inStack1 + inStack2 == sizeArr)
    {
        return true;
    }
    
    return false;
}

template <class T>
bool TwoStackOptimal<T>::isFullStack2()
{
    if (inStack1 + inStack2 == sizeArr)
    {
        return true;
    }
    
    return false;
}

template <class T>
bool TwoStackOptimal<T>::isEmptyStack1()
{
    if (inStack1 == 0)
    {
        return true;
    }
    
    return false;
}

template <class T>
bool TwoStackOptimal<T>::isEmptyStack2()
{
    if (inStack2 == 0)
    {
        return true;
    }
    
    return false;
}

// part 3 //////////////////////////////////////////////////////////////////////
template <typename T>
void showTowerStates(int n, stack<T> &A, stack<T> &B, stack<T> &C, char a, char b, char c)
{
    if (n == 1)
    {
        cout << "Moved " << A.top() << " from peg " << a << " to " << c << endl;
        C.push(A.top());
        A.pop();
        return;
    }
    
    showTowerStates(n - 1, A, C, B, a, c, b);
    cout << "Moved " << A.top() << " from peg " << a << " to " << c << endl;
    C.push(A.top());
    A.pop();
    
    showTowerStates(n - 1, B, A, C, b, a, c);
}

template <typename T>
void showTowerStates(int n, stack<T> &A, stack<T> &B, stack<T> &C)
{
    showTowerStates(n, A, B, C, 'A', 'B', 'C');
    
}



#endif