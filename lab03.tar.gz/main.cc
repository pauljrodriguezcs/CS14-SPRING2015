////////////////////
// Paul Rodriguez //
//    861152748   //
// April 20, 2015 //
////////////////////
#include <iostream>
#include "lab3.h"

using namespace std;

int main()
{
    // part one testing...
    // TwoStackFixed<char> t1(11, 6);
    
    // // cout << " t1.popStack1(): " << t1.popStack1() << endl;

    // // cout << "0: " << endl;
    // t1.pushStack1('g');
    // // cout << "1: " << endl;
    // t1.pushStack1('f');
    // // cout << "2: " << endl;
    // t1.pushStack1('e');
    // // cout << "3: " << endl;
    // t1.pushStack1('d');
    // // cout << "4: " << endl;
    // t1.pushStack1('c');
    // // cout << "5: " << endl;
    // t1.pushStack1('b');

    
    // cout << "4: " << t1.popStack1() << endl;
    // cout << "3: " << t1.popStack1() << endl;
    // cout << "2: " << t1.popStack1() << endl;
    // cout << "1: " << t1.popStack1() << endl;
    // cout << "0: " << t1.popStack1() << endl;
    // cout << "-1: " << t1.popStack1() << endl;
    
    // cout << " t1.popStack2(): " << t1.popStack2() << endl;
    
    // t1.pushStack2(4);
    // t1.pushStack2(3);
    // t1.pushStack2(2);
    // t1.pushStack2(1);
    // t1.pushStack2(0);
    // t1.pushStack2(-1);
    
    // cout << "5: " << t1.popStack2() << endl;
    // cout << "6: " << t1.popStack2() << endl;
    // cout << "7: " << t1.popStack2() << endl;
    // cout << "8: " << t1.popStack2() << endl;
    // cout << "9: " << t1.popStack2() << endl;
    // cout << "10: " << t1.popStack2() << endl;
    
    //part 2 testing...
    
    // TwoStackOptimal<char> t1(13);
    
    // t1.pushFlexStack1('a'); // 0
    // t1.pushFlexStack1('b'); // 1
    // t1.pushFlexStack1('c'); // 2
    // t1.pushFlexStack1('d'); // 3
    // t1.pushFlexStack1('e'); // 4
    // t1.pushFlexStack1('f'); // 5
    
    // t1.pushFlexStack2('h'); // 9
    // t1.pushFlexStack2('i'); // 8
    // t1.pushFlexStack2('o'); // 7
    // t1.pushFlexStack2('l'); // 6
    // t1.pushFlexStack2('t'); // -1
    // t1.pushFlexStack2('p'); // -1
    
    
    // cout << t1.popFlexStack1() << endl;
    // cout << t1.popFlexStack1() << endl;
    // cout << t1.popFlexStack1() << endl;
    // cout << t1.popFlexStack1() << endl;
    // cout << t1.popFlexStack1() << endl;
    // cout << t1.popFlexStack1() << endl;
    // cout << t1.popFlexStack2() << endl;
    // cout << t1.popFlexStack2() << endl;
    // cout << t1.popFlexStack2() << endl;
    // cout << t1.popFlexStack2() << endl;
    // cout << t1.popFlexStack2() << endl;
    // cout << t1.popFlexStack2() << endl;
    
    // stack<string> pA;
    // stack<string> pB;
    // stack<string> pC;
    
    // pA.push("three");
    // pA.push("two");
    // pA.push("one");
    
    
    
    // showTowerStates(3, pA, pB, pC);
    
    // while(!pC.empty())
    // {
    //     cout << pC.top() << endl;
    //     pC.pop();
    // }
    
    // return 0;
}